import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
import math
import time

class OP3ForwardWalkingNode(Node):
    def __init__(self):
        super().__init__('op3_forward_walking_node')
        self.joint_pub = self.create_publisher(JointState, 'joint_states', 10)
        
        # --- 官方物理常數 (m) ---
        self.thigh = 0.093   
        self.calf = 0.093    
        self.ankle_h = 0.0335
        self.leg_length = 0.2195 
        
        # --- YAML 參數與偏移量 ---
        self.x_offset = -0.02
        self.hip_offset = 7.0 * math.pi / 180.0 
        
        # --- 屈膝步態控制 ---
        self.walk_z = 0.18    # 基礎高度 0.18m 確保屈膝
        self.step_h = 0.04    # 抬腳高度
        self.step_l = 0.03    # 往前跨步長
        self.period = 1.0     
        
        self.joint_names = [
            'l_hip_yaw', 'l_hip_roll', 'l_hip_pitch', 'l_knee', 'l_ank_pitch', 'l_ank_roll',
            'r_hip_yaw', 'r_hip_roll', 'r_hip_pitch', 'r_knee', 'r_ank_pitch', 'r_ank_roll',
            'l_sho_pitch', 'l_sho_roll', 'l_el', 'r_sho_pitch', 'r_sho_roll', 'r_el',
            'head_pan', 'head_tilt'
        ]
        self.current_joints = {name: 0.0 for name in self.joint_names}
        self.start_time = time.time()
        self.create_timer(0.02, self.walking_loop)

    def calculate_ik(self, x, z):
        """核心 IK 修正：強迫膝蓋向前彎曲，腳底平行"""
        try:
            # 轉換座標系到髖部中心 (Z 向下為正)
            target_z = z - self.ankle_h
            dist_sq = x**2 + target_z**2
            dist = math.sqrt(dist_sq)
            
            # 安全範圍限制
            max_reach = (self.thigh + self.calf) * 0.98
            dist = max(0.01, min(dist, max_reach))
            
            # 餘弦定理求膝蓋角
            cos_knee = (self.thigh**2 + self.calf**2 - dist_sq) / (2 * self.thigh * self.calf)
            # 修正：轉換為關節旋轉量，確保向前方屈膝
            knee_angle = math.pi - math.acos(max(-1.0, min(1.0, cos_knee)))
            
            # 髖部角度
            phi1 = math.atan2(x, target_z)
            phi2 = math.acos(max(-1.0, min(1.0, (self.thigh**2 + dist_sq - self.calf**2) / (2 * self.thigh * dist))))
            hip_p = phi1 + phi2
            
            # 腳踝俯仰補償：維持平行足底
            # 補償公式：腳踝旋轉量 = 膝蓋旋轉量 - 髖部旋轉量
            ank_p = knee_angle - hip_p 
            
            return hip_p, knee_angle, ank_p
        except:
            return 0.0, 0.0, 0.0

    def walking_loop(self):
        t = (time.time() - self.start_time) % self.period
        phase = (2 * math.pi / self.period) * t
        
        # 1. 左右重心移動 (y_swap)
        swap_y = 0.015 * math.sin(phase)
        
        # 2. X, Z 軸跨步軌跡 (橢圓跨步)
        # 左腳
        z_l, x_l = self.walk_z, self.x_offset
        if math.sin(phase) > 0: # 擺動相 (往前跨)
            z_l -= self.step_h * math.sin(phase)
            x_l += self.step_l * math.cos(phase)
        else: # 支撐相 (往後推)
            x_l -= self.step_l * math.cos(phase + math.pi)

        # 右腳 (相位偏移 pi)
        z_r, x_r = self.walk_z, self.x_offset
        if math.sin(phase + math.pi) > 0:
            z_r -= self.step_h * math.sin(phase + math.pi)
            x_r += self.step_l * math.cos(phase + math.pi)
        else:
            x_r -= self.step_l * math.cos(phase)

        # 執行 IK 解算
        hp_l, kn_l, ap_l = self.calculate_ik(x_l, z_l)
        hp_r, kn_r, ap_r = self.calculate_ik(x_r, z_r)

        # --- 套用關節與正負號修正 ---
        # 左腿
        self.current_joints['l_hip_pitch'] = hp_l + self.hip_offset
        self.current_joints['l_knee'] = kn_l
        self.current_joints['l_ank_pitch'] = -ap_l # 反向補償水平
        self.current_joints['l_hip_roll'] = swap_y
        
        # 右腿 (方向鏡像)
        self.current_joints['r_hip_pitch'] = -(hp_r + self.hip_offset)
        self.current_joints['r_knee'] = -kn_r
        self.current_joints['r_ank_pitch'] = ap_r # 正向補償水平
        self.current_joints['r_hip_roll'] = swap_y

        # 手臂與手肘調整
        self.current_joints['l_sho_pitch'] = -0.4
        self.current_joints['r_sho_pitch'] = 0.4
        self.current_joints['l_el'] = -0.5
        self.current_joints['r_el'] = 0.5

        # 發布 JointState
        msg = JointState()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.name = self.joint_names
        msg.position = [float(self.current_joints[n]) for n in self.joint_names]
        self.joint_pub.publish(msg)

def main():
    rclpy.init(); rclpy.spin(OP3ForwardWalkingNode()); rclpy.shutdown()

if __name__ == '__main__':
    main()