import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, TimerAction, SetEnvironmentVariable
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command, LaunchConfiguration
from launch_ros.actions import Node

def generate_launch_description():
    pkg_op3_description = get_package_share_directory('op3_description')
    pkg_gazebo_ros = get_package_share_directory('gazebo_ros')
    
    robot_controllers_yaml = os.path.join(pkg_op3_description, 'config', 'op3_controllers.yaml')

    xacro_file = os.path.join(pkg_op3_description, 'urdf', 'robotis_op3.urdf.xacro')

    robot_description_content = Command(['xacro ', xacro_file])
    robot_description = {'robot_description': robot_description_content}

    set_opengl_software = SetEnvironmentVariable('LIBGL_ALWAYS_SOFTWARE', '1')
    
    install_share_path = os.path.join(os.path.dirname(pkg_op3_description))
    set_gazebo_model_path = SetEnvironmentVariable(
        'GAZEBO_MODEL_PATH', 
        f"{os.environ.get('GAZEBO_MODEL_PATH', '')}:{install_share_path}"
    )

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_gazebo_ros, 'launch', 'gazebo.launch.py')
        )
    )

    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[{
            'robot_description': robot_description_content,
            'use_sim_time': True
        }]
    )

    spawn_entity = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=[
            '-topic', 'robot_description', 
            '-entity', 'op3', 
            '-z', '0.3'
        ],
        output='screen'
    )

    load_joint_state_broadcaster = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["joint_state_broadcaster", "--controller-manager", "/controller_manager"],
    )

    load_position_controller = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["position_controller", "--controller-manager", "/controller_manager"],
    )

    return LaunchDescription([
        set_opengl_software,
        set_gazebo_model_path,
        
        gazebo,
        robot_state_publisher,
        spawn_entity,
        
        TimerAction(period=10.0, actions=[load_joint_state_broadcaster]),
        TimerAction(period=15.0, actions=[load_position_controller]),
    ])